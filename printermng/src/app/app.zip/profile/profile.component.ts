import { Component, OnInit } from '@angular/core';
import { SalesComponent } from '../sales/sales.component';
import { SalesService } from '../sales.service';
import * as Chart from 'chart.js';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  constructor(private service: SalesService) {}

  ngOnInit(): void {
    this.service.getMonthProfile().subscribe((res) => {
      this.monthProfileResult = res;
    });
    this.service.getPrinterProfile().subscribe((res) => {
      this.printerProfileResult = res;
    });

    const documentStyle = getComputedStyle(document.documentElement);
    const textColor = documentStyle.getPropertyValue('--text-color');
    const textColorSecondary = documentStyle.getPropertyValue(
      '--text-color-secondary'
    );
    const surfaceBorder = documentStyle.getPropertyValue('--surface-border');

    this.data = {
      labels: [
        '一月份',
        '二月份',
        '三月份',
        '四月份',
        '五月份',
        '六月份',
        '七月份',
        '八月份',
        '九月份',
        '十月份',
        '十一月份',
        '十二月份',
      ],
      datasets: [
        {
          label: '2023年度销售利润',
          backgroundColor: documentStyle.getPropertyValue('--blue-500'),
          borderColor: documentStyle.getPropertyValue('--blue-500'),
          data: [65, 59, 80, 81, 56, 55, 40, 2, 2, 2, 2, 2],
        },
      ],
    };

    this.options = {
      maintainAspectRatio: false,
      aspectRatio: 0.8,
      plugins: {
        legend: {
          labels: {
            color: textColor,
          },
        },
      },
      scales: {
        x: {
          ticks: {
            color: textColorSecondary,
            font: {
              weight: 500,
            },
          },
          grid: {
            color: surfaceBorder,
            drawBorder: false,
          },
        },
        y: {
          ticks: {
            color: textColorSecondary,
          },
          grid: {
            color: surfaceBorder,
            drawBorder: false,
          },
        },
      },
    };
  }

  data: any;

  options: any;

  monthProfileResult: any;
  printerProfileResult: any;
}
