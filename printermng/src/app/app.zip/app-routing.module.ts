import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SalesComponent } from './sales/sales.component';
import { HomeComponent } from './home/home.component';
import { SalesHistoryComponent } from './sales-history/sales-history.component';
import { ProcureComponent } from './procure/procure.component';
import { CommonModule } from '@angular/common';
import { WarehouseComponent } from './warehouse/warehouse.component';
import { ProfileComponent } from './profile/profile.component';
const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'procure', component: ProcureComponent },
  { path: 'sales', component: SalesComponent },
  { path: 'salesHistory', component: SalesHistoryComponent },
  { path: 'warehouse', component: WarehouseComponent },
  { path: 'profile', component: ProfileComponent },
];

@NgModule({
  imports: [CommonModule, RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
