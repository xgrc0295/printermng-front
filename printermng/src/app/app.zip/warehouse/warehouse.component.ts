import { Component, OnInit } from '@angular/core';
import { SalesService } from '../sales.service';

@Component({
  selector: 'app-warehouse',
  templateUrl: './warehouse.component.html',
  styleUrls: ['./warehouse.component.css'],
})
export class WarehouseComponent implements OnInit {
  constructor(private service: SalesService) {}

  ngOnInit(): void {
    this.service.getWarehouses().subscribe((res) => {
      this.warehouseResult = res;
    });
  }
  warehouseResult: any;
}
