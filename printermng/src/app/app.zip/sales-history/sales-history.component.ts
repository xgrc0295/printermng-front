import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SalesService } from '../sales.service';
import { ConfirmationService, MessageService } from 'primeng/api';

@Component({
  selector: 'app-sales-history',
  templateUrl: './sales-history.component.html',
  styleUrls: ['./sales-history.component.css'],
})
export class SalesHistoryComponent {
  constructor(
    private service: SalesService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService
  ) {}

  ngOnInit() {}

  //搜索销售
  searchSalesResult: any;

  searchSalesFormGroup: FormGroup = new FormGroup({
    printerName: new FormControl(),
    customerName: new FormControl(),
    empName: new FormControl(),
    notes: new FormControl(),
  });

  public searchSales() {
    this.service
      .searchSales(this.searchSalesFormGroup.value)
      .subscribe((res) => {
        this.searchSalesResult = res;
        this.totalRecords = this.searchSalesResult.length;
      });
  }

  // 分页相关
  first = 0;
  rows = 5;
  totalRecords = 0;
  onPageChange(event: any) {
    this.first = event.first;
    this.rows = event.rows;
  }

  // 删除销售信息

  confirm(event: Event, salesId: number) {
    const targetElement = event.target as HTMLElement;
    this.confirmationService.confirm({
      target: targetElement,
      message: '你确定要删除此销售数据吗？',
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: '确认',
      rejectLabel: '取消',
      accept: () => {
        this.service.deleteSales(salesId).subscribe(() => {
          this.searchSales();
        });
        this.messageService.add({
          severity: 'info',
          summary: '确认',
          detail: 'You have accepted',
        });
      },
      reject: () => {
        this.messageService.add({
          severity: 'error',
          summary: '取消',
          detail: 'You have rejected',
        });
      },
    });
  }
}
